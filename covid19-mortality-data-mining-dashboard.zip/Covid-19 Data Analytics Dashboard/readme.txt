How to Run the Streamlit App
Requirements:
-Python 3.9 or above

Required Libraries
This app uses:
-streamlit
-pandas
-plotly
-base64 (built-in)
-pickle (built-in)

Install Dependencies (if not installed):
pip install streamlit pandas plotly
Run the Application

Open the project folder in VS Code
Open the terminal
Run:

python -m streamlit run app.py

The dashboard will open automatically in a web browser.